
public class Pooltable {

	int first,total_literals;
	public Pooltable(int f,int l)
	{
		this.first=f;
		this.total_literals=l;
	}
}
