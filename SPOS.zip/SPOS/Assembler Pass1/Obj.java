
public class Obj {

	String name;
	int addr;
	Obj(String nm,int address)
	{
	this.name=nm;
	this.addr=address;
	}

}
